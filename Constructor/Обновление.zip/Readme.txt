Файл Version.xml используется отсюда: 
https://github.com/fox951/Constructor-XML/tree/main/Constructor/Version.xml
В обработке проверяется актуальная версия из файла Version.xml.

Если версия совпадает - обработка актуальна.

-----------------------------------
Файл ChangeLog.xml используется отсюда: 
https://github.com/fox951/Constructor-XML/tree/main/Constructor/ChangeLog.xml
В обработке перечень изменений постоянно обновляется из указанного репозитория
и выводится пользователю при запуске.